const fs = require('fs');
const path = require('path');
const express = require('express');
const app = express();

app.use(express.static('public'));
app.use(express.json());

const baseDirectory = 'C:\\Users\\abhis';

function sortFilesByExtension(directory, copyFiles) {
    const files = fs.readdirSync(directory);
    const sortedFolderName = path.basename(directory) + ' Sorted';
    const sortedFolderPath = path.join(path.dirname(directory), 'Sorted', sortedFolderName);
    const sortedParentPath = path.join(path.dirname(directory), 'Sorted');
    if (!fs.existsSync(sortedParentPath)) fs.mkdirSync(sortedParentPath);
    if (!fs.existsSync(sortedFolderPath)) fs.mkdirSync(sortedFolderPath);
    files.forEach(file => {
        const oldPath = path.join(directory, file);
        if (!fs.statSync(oldPath).isFile()) return;
        const ext = path.extname(file).toLowerCase();
        const extFolder = path.join(sortedFolderPath, ext.substring(1) || 'no_extension');
        if (!fs.existsSync(extFolder)) fs.mkdirSync(extFolder);
        const newPath = path.join(extFolder, file);
        if (fs.existsSync(newPath)) {
            console.log(`Duplicate detected: ${path.basename(newPath)}`);
        } else {
            if (copyFiles) fs.copyFileSync(oldPath, newPath);
            else fs.renameSync(oldPath, newPath);
        }
    });
    return sortedFolderPath;
}

async function searchWithOllama(filePaths, query, res) {
    console.log('Querying Ollama with files:', filePaths);
    const readableExtensions = ['.txt', '.docx', '.pptx', '.pdf', '.png'];
    const excludePatterns = ['_rels', '[Content_Types].xml'];
    let readableFiles = [];
    for (const filePath of filePaths) {
        const fileName = path.basename(filePath);
        if (fs.statSync(filePath).isFile() && 
            readableExtensions.includes(path.extname(filePath).toLowerCase()) && 
            !excludePatterns.some(pattern => fileName.includes(pattern))) {
            try {
                const content = fs.readFileSync(filePath, 'utf8');
                readableFiles.push({ filePath, content: content.slice(0, 1500) });
            } catch (e) {
                console.log(`Skipping ${fileName}: Cannot read as text (${e.message})`);
            }
        }
    }
    console.log('Readable files found:', readableFiles.length);
    if (readableFiles.length === 0) {
        res.write("No readable files found.\n");
        res.end();
        return;
    }
    const fileList = readableFiles.map(f => path.basename(f.filePath)).join(', ');
    const combinedContent = readableFiles.map(f => `${path.basename(f.filePath)}: ${f.content}`).join('\n');
    const prompt = `Based on the following text from multiple files:\n"${combinedContent.slice(0, 4000)}"\nAnswer this question naturally and concisely: "${query}". Then, list the filenames (from: ${fileList}) that contain data or keywords related to this query, or say "None" if no files are relevant. Format the list as "Files: filename1, filename2" or "Files: None".`;
    try {
        const response = await fetch('http://localhost:11434/api/generate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                model: 'gemma3:1b',
                prompt: prompt,
                stream: true,
                temperature: 0.7,
                max_tokens: 200
            })
        });
        console.log('Ollama response status:', response.status);
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let fullResponse = '';
        while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            const chunk = decoder.decode(value);
            const lines = chunk.split('\n');
            for (const line of lines) {
                if (line.trim()) {
                    try {
                        const json = JSON.parse(line);
                        if (json.response) {
                            res.write(json.response);
                            fullResponse += json.response;
                        }
                    } catch (e) {
                    }
                }
            }
        }
        res.write('\n');
        const fileMatch = fullResponse.match(/Files: (.+)$/);
        res.write("Files with related data or keywords:\n");
        if (fileMatch && fileMatch[1] && fileMatch[1] !== 'None') {
            const matchedFiles = fileMatch[1].split(', ').map(f => f.trim());
            matchedFiles.forEach((file, index) => {
                res.write(`${index + 1}. ${file}\n`);
            });
        } else {
            res.write("No files contain data or keywords related to this query.\n");
        }
        res.end();
    } catch (e) {
        console.error('Ollama fetch error:', e.message);
        res.write('Error contacting AI service: ' + e.message + '\n');
        res.end();
    }
}

app.get('/folders', (req, res) => {
    const folders = fs.readdirSync(baseDirectory, { withFileTypes: true })
        .filter(dirent => dirent.isDirectory())
        .map(dirent => dirent.name);
    res.json(folders);
});

app.post('/sort', (req, res) => {
    const { folder, copyFiles } = req.body;
    const directoryPath = path.join(baseDirectory, folder);
    try {
        fs.readdirSync(directoryPath);
        const sortedFolderPath = sortFilesByExtension(directoryPath, copyFiles);
        res.json({ sortedFolderPath, message: 'Files organized successfully.' });
    } catch (e) {
        if (e.code === 'ENOENT') {
            res.status(400).json({ error: `Folder '${folder}' does not exist.` });
        } else {
            res.status(500).json({ error: e.message });
        }
    }
});

app.post('/query', (req, res) => {
    const { sortedFolderPath, query } = req.body;
    const filePaths = fs.readdirSync(sortedFolderPath, { recursive: true })
        .filter(f => fs.statSync(path.join(sortedFolderPath, f)).isFile())
        .map(f => path.join(sortedFolderPath, f));
    res.setHeader('Content-Type', 'text/plain');
    res.setHeader('Transfer-Encoding', 'chunked');
    searchWithOllama(filePaths, query, res);
});

app.listen(3000, () => {
    console.log('Server running at http://localhost:3000');
});