const fs = require('fs');
const path = require('path');
const express = require('express');
const app = express();

app.use(express.static('public'));
app.use(express.json());

const baseDirectory = 'C:\\Users\\abhis';

function sortFilesByExtension(directory, copyFiles) {
    const files = fs.readdirSync(directory);
    const sortedFolderName = path.basename(directory) + ' Sorted';
    const sortedFolderPath = path.join(path.dirname(directory), 'Sorted', sortedFolderName);
    const sortedParentPath = path.join(path.dirname(directory), 'Sorted');
    if (!fs.existsSync(sortedParentPath)) fs.mkdirSync(sortedParentPath);
    if (!fs.existsSync(sortedFolderPath)) fs.mkdirSync(sortedFolderPath);
    files.forEach(file => {
        const oldPath = path.join(directory, file);
        if (!fs.statSync(oldPath).isFile()) return;
        const ext = path.extname(file).toLowerCase();
        const extFolder = path.join(sortedFolderPath, ext.substring(1) || 'no_extension');
        if (!fs.existsSync(extFolder)) fs.mkdirSync(extFolder);
        const newPath = path.join(extFolder, file);
        if (fs.existsSync(newPath)) {
            console.log(`Duplicate detected: ${path.basename(newPath)}`);
        } else {
            if (copyFiles) fs.copyFileSync(oldPath, newPath);
            else fs.renameSync(oldPath, newPath);
        }
    });
    return sortedFolderPath;
}

async function searchWithOllama(filePaths, query, res) {
    const readableExtensions = ['.txt', '.docx', '.pptx', '.pdf', '.png'];
    const excludePatterns = ['_rels', '[Content_Types].xml'];
    let readableFiles = [];
    for (const filePath of filePaths) {
        const fileName = path.basename(filePath);
        if (fs.statSync(filePath).isFile() && 
            readableExtensions.includes(path.extname(filePath).toLowerCase()) && 
            !excludePatterns.some(pattern => fileName.includes(pattern))) {
            try {
                const content = fs.readFileSync(filePath, 'utf8');
                readableFiles.push({ filePath, content: content.slice(0, 1500) });
            } catch (e) {
                console.log(`Skipping ${fileName}: Cannot read as text (${e.message})`);
            }
        }
    }
    if (readableFiles.length === 0) {
        res.write("Answer: No readable files found to answer the query.\nRelevant Files: None\n");
        res.end();
        return;
    }
    // Clean file names for readability
    const cleanFileList = readableFiles.map(f => {
        let name = path.basename(f.filePath);
        return name.replace(/[-,\[\]\.\s]+/g, ' ').replace(/\s+/g, ' ').trim();
    });
    const fileList = cleanFileList.join(', ');
    const combinedContent = readableFiles.map((f, i) => `${cleanFileList[i]}: ${f.content}`).join('\n');
    // GPT-like prompt
    const prompt = `You are a helpful AI assistant similar to GPT. Based on the following text from multiple files:\n"${combinedContent.slice(0, 4000)}"\nAnswer this question naturally and concisely: "${query}". Then, list only the filenames (from: ${fileList}) that contain data or keywords directly related to this query. If no files are relevant, say "None". Format your response as:\nAnswer: [your answer]\nRelevant Files: [file1, file2, ...] or None`;
    try {
        const response = await fetch('http://localhost:11434/api/generate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                model: 'gemma3:1b',
                prompt: prompt,
                stream: true,
                temperature: 0.7,
                max_tokens: 200
            })
        });
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let fullResponse = '';
        while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            const chunk = decoder.decode(value);
            const lines = chunk.split('\n');
            for (const line of lines) {
                if (line.trim()) {
                    try {
                        const json = JSON.parse(line);
                        if (json.response) {
                            fullResponse += json.response;
                            res.write(json.response);
                        }
                    } catch (e) {
                    }
                }
            }
        }
        res.write('\n'); // Ensure newline after stream
        res.end();
    } catch (e) {
        res.write(`Answer: Error contacting AI service: ${e.message}\nRelevant Files: None\n`);
        res.end();
    }
}

app.get('/folders', (req, res) => {
    const folders = fs.readdirSync(baseDirectory, { withFileTypes: true })
        .filter(dirent => dirent.isDirectory())
        .map(dirent => dirent.name);
    res.json(folders);
});

app.post('/sort', (req, res) => {
    const { folder, copyFiles } = req.body;
    const directoryPath = path.join(baseDirectory, folder);
    try {
        fs.readdirSync(directoryPath);
        const sortedFolderPath = sortFilesByExtension(directoryPath, copyFiles);
        res.json({ sortedFolderPath, message: 'Files organized successfully.' });
    } catch (e) {
        if (e.code === 'ENOENT') {
            res.status(400).json({ error: `Folder '${folder}' does not exist.` });
        } else {
            res.status(500).json({ error: e.message });
        }
    }
});

app.post('/query', (req, res) => {
    const { sortedFolderPath, query } = req.body;
    const filePaths = fs.readdirSync(sortedFolderPath, { recursive: true })
        .filter(f => fs.statSync(path.join(sortedFolderPath, f)).isFile())
        .map(f => path.join(sortedFolderPath, f));
    res.setHeader('Content-Type', 'text/plain');
    res.setHeader('Transfer-Encoding', 'chunked');
    searchWithOllama(filePaths, query, res);
});

app.listen(3000, () => {
    console.log('Server running at http://localhost:3000');
});